-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 17, 2021 at 05:36 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_ejobassistance`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(100) NOT NULL auto_increment,
  `admin_username` varchar(50) NOT NULL,
  `admin_password` varchar(50) NOT NULL,
  PRIMARY KEY  (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_username`, `admin_password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_complaint`
--

CREATE TABLE `tbl_complaint` (
  `complaint_id` int(100) NOT NULL auto_increment,
  `complaint_details` varchar(1000) NOT NULL,
  `complaint_date` date NOT NULL,
  `complaint_reply` varchar(100) NOT NULL,
  `complaint_status` varchar(100) NOT NULL default 'No Replay',
  `jobseeker_id` int(100) NOT NULL,
  `complaint_subject` varchar(500) NOT NULL,
  PRIMARY KEY  (`complaint_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_complaint`
--

INSERT INTO `tbl_complaint` (`complaint_id`, `complaint_details`, `complaint_date`, `complaint_reply`, `complaint_status`, `jobseeker_id`, `complaint_subject`) VALUES
(1, 'ghfdg', '2021-12-17', 'fgfdg', '1', 20, 'fgdg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_district`
--

CREATE TABLE `tbl_district` (
  `district_id` int(100) NOT NULL auto_increment,
  `district_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`district_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_district`
--

INSERT INTO `tbl_district` (`district_id`, `district_name`) VALUES
(1, 'Ernakulam'),
(2, 'Idukki'),
(3, 'Kottayam');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_feedback`
--

CREATE TABLE `tbl_feedback` (
  `feedback_id` int(100) NOT NULL auto_increment,
  `feedback_details` varchar(500) NOT NULL,
  `feedback_date` date NOT NULL,
  `jobseeker_id` int(11) NOT NULL,
  PRIMARY KEY  (`feedback_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_feedback`
--

INSERT INTO `tbl_feedback` (`feedback_id`, `feedback_details`, `feedback_date`, `jobseeker_id`) VALUES
(2, 'good', '0000-00-00', 0),
(4, 'not bad', '0000-00-00', 0),
(5, 'bad', '0000-00-00', 0),
(6, 'gdfg', '2021-12-17', 20);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jobapplication`
--

CREATE TABLE `tbl_jobapplication` (
  `appln_id` int(11) NOT NULL auto_increment,
  `appln_date` date NOT NULL,
  `rec_id` int(11) NOT NULL,
  `jobseeker_id` int(11) NOT NULL,
  `appln_status` int(11) NOT NULL,
  PRIMARY KEY  (`appln_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_jobapplication`
--

INSERT INTO `tbl_jobapplication` (`appln_id`, `appln_date`, `rec_id`, `jobseeker_id`, `appln_status`) VALUES
(1, '2021-10-10', 1, 20, 1),
(2, '2021-12-17', 1, 20, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jobcategory`
--

CREATE TABLE `tbl_jobcategory` (
  `category_id` int(100) NOT NULL auto_increment,
  `category_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_jobcategory`
--

INSERT INTO `tbl_jobcategory` (`category_id`, `category_name`) VALUES
(2, 'Office Staff'),
(3, 'Accountant');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jobseeker`
--

CREATE TABLE `tbl_jobseeker` (
  `jobseeker_id` int(100) NOT NULL auto_increment,
  `jobseeker_name` varchar(50) NOT NULL,
  `jobseeker_contact` varchar(50) NOT NULL,
  `jobseeker_email` varchar(50) NOT NULL,
  `jobseeker_address` varchar(100) NOT NULL,
  `jobseeker_resume` varchar(150) NOT NULL,
  `jobseeker_photo` varchar(34) NOT NULL,
  `jobseeker_status` varchar(50) NOT NULL,
  `jobseeker_password` varchar(34) NOT NULL,
  `place_id` int(50) NOT NULL,
  `jobseeker_gender` varchar(7) NOT NULL,
  `jobseeker_doj` date NOT NULL,
  PRIMARY KEY  (`jobseeker_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `tbl_jobseeker`
--

INSERT INTO `tbl_jobseeker` (`jobseeker_id`, `jobseeker_name`, `jobseeker_contact`, `jobseeker_email`, `jobseeker_address`, `jobseeker_resume`, `jobseeker_photo`, `jobseeker_status`, `jobseeker_password`, `place_id`, `jobseeker_gender`, `jobseeker_doj`) VALUES
(20, 'Arun Jose', '9446417000', 'arunjose@gmail.com', 'Muvattupuzha', 'rose.ico', 'Gaia.ico', '1', '123456', 7, 'Male', '2021-10-09');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jobsubcategory`
--

CREATE TABLE `tbl_jobsubcategory` (
  `subcategory_id` int(100) NOT NULL auto_increment,
  `subcategory_name` varchar(50) NOT NULL,
  `category_id` int(100) NOT NULL,
  PRIMARY KEY  (`subcategory_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_jobsubcategory`
--

INSERT INTO `tbl_jobsubcategory` (`subcategory_id`, `subcategory_name`, `category_id`) VALUES
(4, 'Front Office Staff', 2),
(5, 'Senior Accountant', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_place`
--

CREATE TABLE `tbl_place` (
  `place_id` int(100) NOT NULL auto_increment,
  `district_id` int(100) NOT NULL,
  `place_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`place_id`),
  KEY `diatrict_place` (`district_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_place`
--

INSERT INTO `tbl_place` (`place_id`, `district_id`, `place_name`) VALUES
(7, 1, 'Muvattupuzha'),
(8, 2, 'Thodupuzha'),
(9, 3, 'Ettumanoor');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_recruiter`
--

CREATE TABLE `tbl_recruiter` (
  `recruiter_id` int(100) NOT NULL auto_increment,
  `recruiter_name` varchar(34) NOT NULL,
  `recruiter_address` varchar(700) NOT NULL,
  `recruiter_contact` varchar(20) NOT NULL,
  `recruiter_email` varchar(50) NOT NULL,
  `recruiter_proof` varchar(50) NOT NULL,
  `recruiter_photo` varchar(80) NOT NULL,
  `recruiter_password` varchar(50) NOT NULL,
  `place_id` int(100) NOT NULL,
  `recruiter_doj` date NOT NULL,
  `recruiter_status` int(11) NOT NULL,
  PRIMARY KEY  (`recruiter_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_recruiter`
--

INSERT INTO `tbl_recruiter` (`recruiter_id`, `recruiter_name`, `recruiter_address`, `recruiter_contact`, `recruiter_email`, `recruiter_proof`, `recruiter_photo`, `recruiter_password`, `place_id`, `recruiter_doj`, `recruiter_status`) VALUES
(1, 'ADCOM Consulatancy', 'Muvattupuzha', '9446417885', 'adcom@gmail.com', 'Gaia.ico', 'Icondrawer-Gifts-Dog.ico', '123456', 7, '2021-10-09', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_recruitment`
--

CREATE TABLE `tbl_recruitment` (
  `rec_id` int(100) NOT NULL auto_increment,
  `rec_postname` varchar(700) NOT NULL,
  `rec_company` varchar(700) NOT NULL,
  `rec_salary` varchar(100) NOT NULL,
  `rec_vaccancyno` varchar(100) NOT NULL,
  `subcategory_id` int(59) NOT NULL,
  `recruiter_id` int(100) NOT NULL,
  `rec_address` varchar(700) NOT NULL,
  `rec_details` varchar(700) NOT NULL,
  `rec_status` int(11) NOT NULL,
  `rec_date` varchar(700) NOT NULL,
  PRIMARY KEY  (`rec_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_recruitment`
--

INSERT INTO `tbl_recruitment` (`rec_id`, `rec_postname`, `rec_company`, `rec_salary`, `rec_vaccancyno`, `subcategory_id`, `recruiter_id`, `rec_address`, `rec_details`, `rec_status`, `rec_date`) VALUES
(1, 'Front Office Counseller', 'PCPL Muvattupuzha', '12000', '1', 4, 1, 'P.O Junction\r\nMuvattupuzha', 'Minimum Qualification Degree', 1, '1-11-2021');
