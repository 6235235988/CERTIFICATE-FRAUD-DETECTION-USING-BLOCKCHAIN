from django.contrib import admin
from .models import IncomeCertificate,Count,userProfile,subBlock,CasteCertificate,subBlockCaste,Blog
# Register your models here.
# admin.site.register(IncomeCertificate)
# admin.site.register(Count)
admin.site.register(userProfile)
# admin.site.register(subBlock)
# admin.site.register(CasteCertificate)
# admin.site.register(subBlockCaste)
# admin.site.register(Blog)