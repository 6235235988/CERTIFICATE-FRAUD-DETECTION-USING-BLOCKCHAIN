from django.shortcuts import render
from django.http import HttpResponseRedirect, HttpResponse, JsonResponse
from django.contrib.auth import authenticate,logout,login
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from django.db.models import Q
from django.contrib.auth.models import User
from .models import userProfile,IncomeCertificate,Count,subBlock,CasteCertificate,subBlockCaste,Blog,PossessionCertificate,subBlockPossession,NativityCertificate,subBlockNativity
# Create your views here.
added_certificate = 0
found = 0
def homepage(request):
    
    if request.user.is_authenticated:
        profile = userProfile.objects.filter(user = request.user).first()

    else:
        profile = ''
    request.session['found'] = 1
    return render(request,'index.html',context = {'profile':profile})



message = 0
reg_error = 0

def checkSignup(request):
    
    username = request.POST.get('username')
    password = request.POST.get('password')

    
    u = User.objects.filter(username = username).first()
    
    if u == None:
        message = 0
    else:
        message = 1
    
    return JsonResponse({"message":message})



def register(request):
    if request.method == 'POST':
        try:
            user = User.objects.create(username = request.POST.get('username'),email=request.POST.get('email'))
            user.set_password(request.POST.get('password'))
            user.save()
        except:
            pass

        user = User.objects.filter(username=request.POST.get('username')).first()
        
        profile = userProfile.objects.create(user=user)
        profile.phone = request.POST.get('phone')
        profile.address = request.POST.get('address')
        profile.adhaar_no = request.POST.get('adhaar')
        profile.save()
        
            

    return HttpResponseRedirect(reverse('homepage'))


def checkLogin(request):
    
    username = request.POST.get('username')
    password = request.POST.get('password')

    user = authenticate(username = username,password = password)
    if user:
        print(username)
        return JsonResponse({"message":0})
            
    else:
        print("No user found")
        return JsonResponse({"message":1})
        

def user_login(request):
   
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        user = authenticate(username = username,password = password)
        if user:

            if user.is_active:
                login(request, user)
                print("login success!!!")
                return HttpResponseRedirect(reverse('homepage'))
        else:
            
            print("No such user")


    return HttpResponseRedirect(reverse('homepage'))
    
@login_required
def user_logout(request):

    logout(request)


    return HttpResponseRedirect(reverse('homepage'))

from solcx import compile_standard, install_solc
import json 
certificateId = ""
def addIncomeCertificate(request):
    request.session['added_certificate'] = 1
    with open("ContactList.sol", "r") as file:
        contact_list_file = file.read()

    #to save the output in a JSON file
    
    compiled_sol = compile_standard(
        {
            "language": "Solidity",
            "sources": {"ContactList.sol": {"content": contact_list_file}},
            "settings": {
                "outputSelection": {
                    "*": {
                        "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                    }
                }
            },
        },
        solc_version="0.8.0",
    )
    # print(compiled_sol)
    with open("compiled_code.json", "w") as file:
        json.dump(compiled_sol, file)

    bytecode = compiled_sol["contracts"]["ContactList.sol"]["IncomeCertificate"]["evm"]["bytecode"]["object"]
    abi = json.loads(compiled_sol["contracts"]["ContactList.sol"]["IncomeCertificate"]["metadata"])["output"]["abi"]

    from web3 import Web3
   
    # For connecting to ganache
    w3 = Web3(Web3.HTTPProvider("HTTP://127.0.0.1:7545"))
    chain_id = 1337
    address = "0x800A3BF5d9C6e42fFe4A57c7968618DdE81fd7cA"
    private_key = "e0a9f2f78b2dca326b4116744b422d2ba1ba5c15392492c3c45a2e3fbe9021b0" # leaving the private key like this is very insecure if you are working on real world project
    # Create the contract in Python
    ContactList = w3.eth.contract(abi=abi, bytecode=bytecode)
    # Get the number of latest transaction
    nonce = w3.eth.getTransactionCount(address)

    transaction = ContactList.constructor().buildTransaction(
        {
            "chainId": chain_id,
            "gasPrice": w3.eth.gas_price,
            "from": address,
            "nonce": nonce,
        }
    )
    # Sign the transaction
    sign_transaction = w3.eth.account.sign_transaction(transaction, private_key=private_key)
    print("Deploying Contract!")
    # Send the transaction
    transaction_hash = w3.eth.send_raw_transaction(sign_transaction.rawTransaction)
    # Wait for the transaction to be mined, and get the transaction receipt
    print("Waiting for transaction to finish...")
    transaction_receipt = w3.eth.wait_for_transaction_receipt(transaction_hash)
    print(f"Done! Contract deployed to {transaction_receipt.contractAddress}")
    count = Count.objects.all().first().number
    block = IncomeCertificate.objects.create(certificate_id= "ICID"+str(count),transaction_address = str(transaction_receipt.contractAddress))
    request.session['certificateId'] = "ICID"+str(count)
    cnt = Count.objects.all().first()
    cnt.number = count+1
    cnt.save()
    contact_list = w3.eth.contract(address=transaction_receipt.contractAddress, abi=abi)
    personalInfo = request.POST.get('fullName') + ";" + str(request.POST.get('dob'))+ ";" + request.POST.get("address")+ ";"+request.POST.get("familyMembers")+ ";" + str(request.POST.get('relationship'))+ ";" + request.POST.get("adhaar")
    educationalInfo = request.POST.get("highestQualification")+ ";"+request.POST.get("educationalInstitutions")
    employmentInfo = request.POST.get("employer")+ ";"+request.POST.get("designation")+ ";"+request.POST.get("type_of_organization")+ ";"+request.POST.get("occupation")
    income = request.POST.get('annualIncome')
    
    store_contact = contact_list.functions.addIncomeCertificate(
        personalInfo,educationalInfo,employmentInfo,income
        
    ).buildTransaction({"chainId": chain_id, "from": address, "gasPrice": w3.eth.gas_price, "nonce": nonce + 1})

    # Sign the transaction
    sign_store_contact = w3.eth.account.sign_transaction(
        store_contact, private_key=private_key
    )
    # Send the transaction
    send_store_contact = w3.eth.send_raw_transaction(sign_store_contact.rawTransaction)
    transaction_receipt = w3.eth.wait_for_transaction_receipt(send_store_contact)

    print("saved!!!!!!!!!!!")
    return HttpResponseRedirect(reverse('homepage'))


#For caste certificate ----------------------------------------

def addCasteCertificate(request):
    request.session['added_certificate'] = 1
    with open("ContactList.sol", "r") as file:
        contact_list_file = file.read()

    #to save the output in a JSON file
    
    compiled_sol = compile_standard(
        {
            "language": "Solidity",
            "sources": {"ContactList.sol": {"content": contact_list_file}},
            "settings": {
                "outputSelection": {
                    "*": {
                        "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                    }
                }
            },
        },
        solc_version="0.8.0",
    )
    # print(compiled_sol)
    with open("compiled_code.json", "w") as file:
        json.dump(compiled_sol, file)

    bytecode = compiled_sol["contracts"]["ContactList.sol"]["CasteCertificate"]["evm"]["bytecode"]["object"]
    abi = json.loads(compiled_sol["contracts"]["ContactList.sol"]["CasteCertificate"]["metadata"])["output"]["abi"]

    from web3 import Web3
   
    # For connecting to ganache
    w3 = Web3(Web3.HTTPProvider("HTTP://127.0.0.1:7545"))
    chain_id = 1337
    address = "0x800A3BF5d9C6e42fFe4A57c7968618DdE81fd7cA"
    private_key = "e0a9f2f78b2dca326b4116744b422d2ba1ba5c15392492c3c45a2e3fbe9021b0" # leaving the private key like this is very insecure if you are working on real world project
    # Create the contract in Python
    ContactList = w3.eth.contract(abi=abi, bytecode=bytecode)
    # Get the number of latest transaction
    nonce = w3.eth.getTransactionCount(address)

    transaction = ContactList.constructor().buildTransaction(
        {
            "chainId": chain_id,
            "gasPrice": w3.eth.gas_price,
            "from": address,
            "nonce": nonce,
        }
    )
    # Sign the transaction
    sign_transaction = w3.eth.account.sign_transaction(transaction, private_key=private_key)
    print("Deploying Contract!")
    # Send the transaction
    transaction_hash = w3.eth.send_raw_transaction(sign_transaction.rawTransaction)
    # Wait for the transaction to be mined, and get the transaction receipt
    print("Waiting for transaction to finish...")
    transaction_receipt = w3.eth.wait_for_transaction_receipt(transaction_hash)
    print(f"Done! Contract deployed to {transaction_receipt.contractAddress}")
    count = Count.objects.all().first().number
    block = CasteCertificate.objects.create(certificate_id= "CSTCID"+str(count),transaction_address = str(transaction_receipt.contractAddress))
    request.session['certificateId'] = "CSTCID"+str(count)
    cnt = Count.objects.all().first()
    cnt.number = count+1
    cnt.save()
    contact_list = w3.eth.contract(address=transaction_receipt.contractAddress, abi=abi)
    personalInfo = request.POST.get('full_name')+";"+ request.POST.get('email')+";"+request.POST.get('phone') + ";" + request.POST.get("address")
    certficateInfo = request.POST.get('religion')+";"+request.POST.get('caste')+";"+request.POST.get('father_name')+";"+request.POST.get('mother_name')+";"+request.POST.get('date_of_birth')+";"+request.POST.get('place_of_birth')+";"+request.POST.get('adhaar_number')+";"+request.POST.get('sslc_number')+";"+request.POST.get('ration_number')+";"+request.POST.get('gender')
    # employmentInfo = request.POST.get("employer")+ ";"+request.POST.get("designation")+ ";"+request.POST.get("type_of_organization")+ ";"+request.POST.get("occupation")
    # income = request.POST.get('annualIncome')
    
    store_contact = contact_list.functions.addCasteCertificate(
        personalInfo,certficateInfo
        
    ).buildTransaction({"chainId": chain_id, "from": address, "gasPrice": w3.eth.gas_price, "nonce": nonce + 1})

    # Sign the transaction
    sign_store_contact = w3.eth.account.sign_transaction(
        store_contact, private_key=private_key
    )
    # Send the transaction
    send_store_contact = w3.eth.send_raw_transaction(sign_store_contact.rawTransaction)
    transaction_receipt = w3.eth.wait_for_transaction_receipt(send_store_contact)

    print("saved!!!!!!!!!!!")
    return HttpResponseRedirect(reverse('homepage'))

#--------------------------------------------------------------

# Add possession certificate -----------------------------------

def addPossession(request):
    request.session['added_certificate'] = 1
    with open("ContactList.sol", "r") as file:
        contact_list_file = file.read()

    #to save the output in a JSON file
    
    compiled_sol = compile_standard(
        {
            "language": "Solidity",
            "sources": {"ContactList.sol": {"content": contact_list_file}},
            "settings": {
                "outputSelection": {
                    "*": {
                        "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                    }
                }
            },
        },
        solc_version="0.8.0",
    )
    # print(compiled_sol)
    with open("compiled_code.json", "w") as file:
        json.dump(compiled_sol, file)

    bytecode = compiled_sol["contracts"]["ContactList.sol"]["PossessionCertificate"]["evm"]["bytecode"]["object"]
    abi = json.loads(compiled_sol["contracts"]["ContactList.sol"]["PossessionCertificate"]["metadata"])["output"]["abi"]

    from web3 import Web3
   
    # For connecting to ganache
    w3 = Web3(Web3.HTTPProvider("HTTP://127.0.0.1:7545"))
    chain_id = 1337
    address = "0x800A3BF5d9C6e42fFe4A57c7968618DdE81fd7cA"
    private_key = "e0a9f2f78b2dca326b4116744b422d2ba1ba5c15392492c3c45a2e3fbe9021b0" # leaving the private key like this is very insecure if you are working on real world project
    # Create the contract in Python
    ContactList = w3.eth.contract(abi=abi, bytecode=bytecode)
    # Get the number of latest transaction
    nonce = w3.eth.getTransactionCount(address)

    transaction = ContactList.constructor().buildTransaction(
        {
            "chainId": chain_id,
            "gasPrice": w3.eth.gas_price,
            "from": address,
            "nonce": nonce,
        }
    )
    # Sign the transaction
    sign_transaction = w3.eth.account.sign_transaction(transaction, private_key=private_key)
    print("Deploying Contract!")
    # Send the transaction
    transaction_hash = w3.eth.send_raw_transaction(sign_transaction.rawTransaction)
    # Wait for the transaction to be mined, and get the transaction receipt
    print("Waiting for transaction to finish...")
    transaction_receipt = w3.eth.wait_for_transaction_receipt(transaction_hash)
    print(f"Done! Contract deployed to {transaction_receipt.contractAddress}")
    count = Count.objects.all().first().number
    block = PossessionCertificate.objects.create(certificate_id= "PSCID"+str(count),transaction_address = str(transaction_receipt.contractAddress),username = str(request.user.username))
    request.session['certificateId'] = "PSCID"+str(count)
    cnt = Count.objects.all().first()
    cnt.number = count+1
    cnt.save()
    contact_list = w3.eth.contract(address=transaction_receipt.contractAddress, abi=abi)
    personalInfo = request.POST.get('name')+";"+ request.POST.get('email')+";"+request.POST.get('phone') + ";" + request.POST.get("address")+ ";" + request.POST.get("city")+ ";" + request.POST.get("zip")
    certficateInfo = request.POST.get('property_type')+";"+request.POST.get('property_address')+";"+request.POST.get('property_city')+";"+request.POST.get('property_zip')
    # employmentInfo = request.POST.get("employer")+ ";"+request.POST.get("designation")+ ";"+request.POST.get("type_of_organization")+ ";"+request.POST.get("occupation")
    # income = request.POST.get('annualIncome')
    
    store_contact = contact_list.functions.addCasteCertificate(
        personalInfo,certficateInfo
        
    ).buildTransaction({"chainId": chain_id, "from": address, "gasPrice": w3.eth.gas_price, "nonce": nonce + 1})

    # Sign the transaction
    sign_store_contact = w3.eth.account.sign_transaction(
        store_contact, private_key=private_key
    )
    # Send the transaction
    send_store_contact = w3.eth.send_raw_transaction(sign_store_contact.rawTransaction)
    transaction_receipt = w3.eth.wait_for_transaction_receipt(send_store_contact)

    print("saved!!!!!!!!!!!")
    return HttpResponseRedirect(reverse('homepage'))

#--------------------------------------------------------------


# for nativity -=----------------------------------------------
def addNativity(request):
    request.session['added_certificate'] = 1
    with open("ContactList.sol", "r") as file:
        contact_list_file = file.read()

    #to save the output in a JSON file
    
    compiled_sol = compile_standard(
        {
            "language": "Solidity",
            "sources": {"ContactList.sol": {"content": contact_list_file}},
            "settings": {
                "outputSelection": {
                    "*": {
                        "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                    }
                }
            },
        },
        solc_version="0.8.0",
    )
    # print(compiled_sol)
    with open("compiled_code.json", "w") as file:
        json.dump(compiled_sol, file)

    bytecode = compiled_sol["contracts"]["ContactList.sol"]["NativityCertificate"]["evm"]["bytecode"]["object"]
    abi = json.loads(compiled_sol["contracts"]["ContactList.sol"]["NativityCertificate"]["metadata"])["output"]["abi"]

    from web3 import Web3
   
    # For connecting to ganache
    w3 = Web3(Web3.HTTPProvider("HTTP://127.0.0.1:7545"))
    chain_id = 1337
    address = "0x800A3BF5d9C6e42fFe4A57c7968618DdE81fd7cA"
    private_key = "e0a9f2f78b2dca326b4116744b422d2ba1ba5c15392492c3c45a2e3fbe9021b0" # leaving the private key like this is very insecure if you are working on real world project
    # Create the contract in Python
    ContactList = w3.eth.contract(abi=abi, bytecode=bytecode)
    # Get the number of latest transaction
    nonce = w3.eth.getTransactionCount(address)

    transaction = ContactList.constructor().buildTransaction(
        {
            "chainId": chain_id,
            "gasPrice": w3.eth.gas_price,
            "from": address,
            "nonce": nonce,
        }
    )
    # Sign the transaction
    sign_transaction = w3.eth.account.sign_transaction(transaction, private_key=private_key)
    print("Deploying Contract!")
    # Send the transaction
    transaction_hash = w3.eth.send_raw_transaction(sign_transaction.rawTransaction)
    # Wait for the transaction to be mined, and get the transaction receipt
    print("Waiting for transaction to finish...")
    transaction_receipt = w3.eth.wait_for_transaction_receipt(transaction_hash)
    print(f"Done! Contract deployed to {transaction_receipt.contractAddress}")
    count = Count.objects.all().first().number
    block = NativityCertificate.objects.create(certificate_id= "NACID"+str(count),transaction_address = str(transaction_receipt.contractAddress),username = str(request.user.username))
    request.session['certificateId'] = "NACID"+str(count)
    cnt = Count.objects.all().first()
    cnt.number = count+1
    cnt.save()
    contact_list = w3.eth.contract(address=transaction_receipt.contractAddress, abi=abi)
    personalInfo = request.POST.get('name')+";"+ request.POST.get('email')+";"+request.POST.get('phone') + ";" + request.POST.get("birth_place")+ ";" + str(request.POST.get("birth_date"))+ ";" + request.POST.get("father_name")+ ";" + request.POST.get("mother_name")+ ";" + request.POST.get("father_occupation")+ ";" + request.POST.get("mother_occupation")
    # certficateInfo = request.POST.get('property_type')+";"+request.POST.get('property_address')+";"+request.POST.get('property_city')+";"+request.POST.get('property_zip')
    # employmentInfo = request.POST.get("employer")+ ";"+request.POST.get("designation")+ ";"+request.POST.get("type_of_organization")+ ";"+request.POST.get("occupation")
    # income = request.POST.get('annualIncome')
    
    store_contact = contact_list.functions.addCasteCertificate(
        personalInfo
        
    ).buildTransaction({"chainId": chain_id, "from": address, "gasPrice": w3.eth.gas_price, "nonce": nonce + 1})

    # Sign the transaction
    sign_store_contact = w3.eth.account.sign_transaction(
        store_contact, private_key=private_key
    )
    # Send the transaction
    send_store_contact = w3.eth.send_raw_transaction(sign_store_contact.rawTransaction)
    transaction_receipt = w3.eth.wait_for_transaction_receipt(send_store_contact)

    print("saved!!!!!!!!!!!")
    return HttpResponseRedirect(reverse('homepage'))

# --------------------------------------------------------------

with open("ContactList.sol", "r") as file:
        contact_list_file = file.read()

    #to save the output in a JSON file
    
compiled_sol = compile_standard(
        {
            "language": "Solidity",
            "sources": {"ContactList.sol": {"content": contact_list_file}},
            "settings": {
                "outputSelection": {
                    "*": {
                        "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                    }
                }
            },
        },
        solc_version="0.8.0",
    )
    # print(compiled_sol)
with open("compiled_code.json", "w") as file:
    json.dump(compiled_sol, file)

bytecode = compiled_sol["contracts"]["ContactList.sol"]["IncomeCertificate"]["evm"]["bytecode"]["object"]
abi = json.loads(compiled_sol["contracts"]["ContactList.sol"]["IncomeCertificate"]["metadata"])["output"]["abi"]


from web3 import Web3
    
    # For connecting to ganache
w3 = Web3(Web3.HTTPProvider("HTTP://127.0.0.1:7545"))


#For status 



def tracking(request):
    # block1 = IncomeCertificate.objects.filter(certificate_id = request.POST.get("query")).first()
    # block2 = CasteCertificate.objects.filter(certificate_id = request.POST.get("query")).first()


    if "ICID" in request.POST.get("query"):
        print("[+] ---------- Tracking  ---------- [+]" )
        with open("status.sol", "r") as file:
            contact_list_file = file.read()

        profile = userProfile.objects.filter(user = request.user).first()
        compiled_sol2 = compile_standard(
            {
                "language": "Solidity",
                "sources": {"status.sol": {"content": contact_list_file}},
                "settings": {
                    "outputSelection": {
                        "*": {
                            "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                        }
                    }
                },
            },
            solc_version="0.8.0",
        )
        # print(compiled_sol)
        with open("compiled_code1.json", "w") as file:
            json.dump(compiled_sol2, file)

        bytecode1 = compiled_sol2["contracts"]["status.sol"]["Status"]["evm"]["bytecode"]["object"]
        abi1 = json.loads(compiled_sol2["contracts"]["status.sol"]["Status"]["metadata"])["output"]["abi"]
        block = IncomeCertificate.objects.filter(certificate_id = request.POST.get("query")).first()
            # request.POST.get('university_name') + str(request.POST.get('date_issued'))+ request.POST.get("c_no")+request.POST.get("reg_no")+request.POST.get("student_name")+request.POST.get("faculty_of")+ request.POST.get("degree_of")+request.POST.get("degree_in")+str(request.POST.get("completed_in"))+ request.POST.get("comp_1")+request.POST.get("comp_2")+request.POST.get("class")+request.POST.get("grade")+request.POST.get("course_name") + str(p_block.current_hash)
        bytecode = compiled_sol["contracts"]["ContactList.sol"]["IncomeCertificate"]["evm"]["bytecode"]["object"]
        abi = json.loads(compiled_sol["contracts"]["ContactList.sol"]["IncomeCertificate"]["metadata"])["output"]["abi"]

        if block:
            test = w3.eth.contract(address=block.transaction_address, abi=abi)
            print(test.functions.retrieve().call())

            result = test.functions.retrieve().call()
            print("result",result[0])
            request.session['found'] = 1
            profile = userProfile.objects.filter(user = request.user).first()
            
            subss = subBlock.objects.filter(block=block)
            subs = []
            added = False
            for sub in subss:
                if sub.user == request.user.username:
                    added = True
                test = w3.eth.contract(address=sub.transaction_address, abi=abi1)
                print(test.functions.retrieve().call())

                results = test.functions.retrieve().call()
                s = {"status":results[0][0],"image":sub.pic,"username":sub.user,"date":sub.dateToday}
                subs.append(s)
            # print({"name":result[0][0].split(";")[0],"address":result[0][0].split(";")[1],"date":result[0][0].split(";")[2],"ipn":result[0][0].split(";")[3],"InsName":result[0][1].split(";")[0],"InsAdd":result[0][1].split(";")[1],"Npi":result[0][1].split(";")[2],"serviceDate":result[0][2].split(";")[0],"desc":result[0][2].split(";")[1],"pcode":result[0][2].split(";")[2],"dcode":result[0][2].split(";")[3],"charge":result[0][2].split(";")[4],"amount":result[0][3],"=====":result[0][4]})
            # return JsonResponse({"name":result[0][0].split(";")[0],"dob":result[0][0].split(";")[1],"address":result[0][0].split(";")[2],"father":result[0][0].split(";")[3],"mother":result[0][0].split(";")[4],"adhaar":result[0][0].split(";")[5],"qualification":result[0][1].split(";")[0],"institute":result[0][1].split(";")[1],"employer":result[0][2].split(";")[0],"designation":result[0][2].split(";")[1],"typeOrg":result[0][2].split(";")[2],"typeOcc":result[0][2].split(";")[3],"amount":result[0][3]})
            return render(request,'tracking.html',{"name":result[0][0].split(";")[0],"dob":result[0][0].split(";")[1],"address":result[0][0].split(";")[2],"father":result[0][0].split(";")[3],"mother":result[0][0].split(";")[4],"adhaar":result[0][0].split(";")[5],"qualification":result[0][1].split(";")[0],"institute":result[0][1].split(";")[1],"employer":result[0][2].split(";")[0],"designation":result[0][2].split(";")[1],"typeOrg":result[0][2].split(";")[2],"typeOcc":result[0][2].split(";")[3],"amount":result[0][3],"profile":profile,"pk":block.pk,"blocks":subs,"added":added,"block":block,"certificate":0})
        else:
            request.session['found'] = 0

        return render(request,'index.html',context = {'profile':profile,"found":found})
    
    elif "CSTCID" in request.POST.get('query'):
        print("[+] ---------- Tracking  ---------- [+]" )
        with open("status.sol", "r") as file:
            contact_list_file = file.read()

        profile = userProfile.objects.filter(user = request.user).first()
        compiled_sol2 = compile_standard(
            {
                "language": "Solidity",
                "sources": {"status.sol": {"content": contact_list_file}},
                "settings": {
                    "outputSelection": {
                        "*": {
                            "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                        }
                    }
                },
            },
            solc_version="0.8.0",
        )
        # print(compiled_sol)
        with open("compiled_code1.json", "w") as file:
            json.dump(compiled_sol2, file)

        bytecode1 = compiled_sol2["contracts"]["status.sol"]["Status"]["evm"]["bytecode"]["object"]
        abi1 = json.loads(compiled_sol2["contracts"]["status.sol"]["Status"]["metadata"])["output"]["abi"]
        block = CasteCertificate.objects.filter(certificate_id = request.POST.get("query")).first()
            # request.POST.get('university_name') + str(request.POST.get('date_issued'))+ request.POST.get("c_no")+request.POST.get("reg_no")+request.POST.get("student_name")+request.POST.get("faculty_of")+ request.POST.get("degree_of")+request.POST.get("degree_in")+str(request.POST.get("completed_in"))+ request.POST.get("comp_1")+request.POST.get("comp_2")+request.POST.get("class")+request.POST.get("grade")+request.POST.get("course_name") + str(p_block.current_hash)
        bytecode = compiled_sol["contracts"]["ContactList.sol"]["CasteCertificate"]["evm"]["bytecode"]["object"]
        abi = json.loads(compiled_sol["contracts"]["ContactList.sol"]["CasteCertificate"]["metadata"])["output"]["abi"]
    
        if block:
            test = w3.eth.contract(address=block.transaction_address, abi=abi)
            print(test.functions.retrieve().call())

            result = test.functions.retrieve().call()
            print("result",result[0])
            request.session['found'] = 1
            profile = userProfile.objects.filter(user = request.user).first()
            
            subss = subBlockCaste.objects.filter(block=block)
            subs = []
            added = False
            for sub in subss:
                if sub.user == request.user.username:
                    added = True
                test = w3.eth.contract(address=sub.transaction_address, abi=abi1)
                print(test.functions.retrieve().call())

                results = test.functions.retrieve().call()
                s = {"status":results[0][0],"image":sub.pic,"username":sub.user,"date":sub.dateToday}
                subs.append(s)
            # print({"name":result[0][0].split(";")[0],"address":result[0][0].split(";")[1],"date":result[0][0].split(";")[2],"ipn":result[0][0].split(";")[3],"InsName":result[0][1].split(";")[0],"InsAdd":result[0][1].split(";")[1],"Npi":result[0][1].split(";")[2],"serviceDate":result[0][2].split(";")[0],"desc":result[0][2].split(";")[1],"pcode":result[0][2].split(";")[2],"dcode":result[0][2].split(";")[3],"charge":result[0][2].split(";")[4],"amount":result[0][3],"=====":result[0][4]})
            # return JsonResponse({"name":result[0][0].split(";")[0],"dob":result[0][0].split(";")[1],"address":result[0][0].split(";")[2],"father":result[0][0].split(";")[3],"mother":result[0][0].split(";")[4],"adhaar":result[0][0].split(";")[5],"qualification":result[0][1].split(";")[0],"institute":result[0][1].split(";")[1],"employer":result[0][2].split(";")[0],"designation":result[0][2].split(";")[1],"typeOrg":result[0][2].split(";")[2],"typeOcc":result[0][2].split(";")[3],"amount":result[0][3]})     +";"+request.POST.get('sslc_number')+";"+request.POST.get('ration_number')+";"+request.POST.get('gender')
            return render(request,'tracking.html',{"name":result[0][0].split(";")[0],"email":result[0][0].split(";")[1],"phone":result[0][0].split(";")[2],"address":result[0][0].split(";")[3],"father":result[0][1].split(";")[2],"mother":result[0][1].split(";")[3],"adhaar":result[0][1].split(";")[6],"religion":result[0][1].split(";")[0],"caste":result[0][1].split(";")[2],"dob":result[0][1].split(";")[4],"place":result[0][1].split(";")[5],"profile":profile,"pk":block.pk,"blocks":subs,"added":added,"block":block,"certificate":1,"blocks":subs,"gender":result[0][1].split(";")[9],"sslc":result[0][1].split(";")[7],"ration":result[0][1].split(";")[8]})
        
        else:
            request.session['found'] = 0
    


        return render(request,'index.html',context = {'profile':profile,"found":found})
    
    elif "PSCID" in request.POST.get('query'):
        print("[+] ---------- Tracking  ---------- [+]" )
        with open("status.sol", "r") as file:
            contact_list_file = file.read()

        profile = userProfile.objects.filter(user = request.user).first()
        compiled_sol2 = compile_standard(
            {
                "language": "Solidity",
                "sources": {"status.sol": {"content": contact_list_file}},
                "settings": {
                    "outputSelection": {
                        "*": {
                            "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                        }
                    }
                },
            },
            solc_version="0.8.0",
        )
        # print(compiled_sol)
        with open("compiled_code1.json", "w") as file:
            json.dump(compiled_sol2, file)

        bytecode1 = compiled_sol2["contracts"]["status.sol"]["Status"]["evm"]["bytecode"]["object"]
        abi1 = json.loads(compiled_sol2["contracts"]["status.sol"]["Status"]["metadata"])["output"]["abi"]
        block = PossessionCertificate.objects.filter(certificate_id = request.POST.get("query")).first()
            # request.POST.get('university_name') + str(request.POST.get('date_issued'))+ request.POST.get("c_no")+request.POST.get("reg_no")+request.POST.get("student_name")+request.POST.get("faculty_of")+ request.POST.get("degree_of")+request.POST.get("degree_in")+str(request.POST.get("completed_in"))+ request.POST.get("comp_1")+request.POST.get("comp_2")+request.POST.get("class")+request.POST.get("grade")+request.POST.get("course_name") + str(p_block.current_hash)
        bytecode = compiled_sol["contracts"]["ContactList.sol"]["PossessionCertificate"]["evm"]["bytecode"]["object"]
        abi = json.loads(compiled_sol["contracts"]["ContactList.sol"]["PossessionCertificate"]["metadata"])["output"]["abi"]
    
        if block:
            test = w3.eth.contract(address=block.transaction_address, abi=abi)
            print(test.functions.retrieve().call())

            result = test.functions.retrieve().call()
            print("result",result[0])
            request.session['found'] = 1
            profile = userProfile.objects.filter(user = request.user).first()
            
            subss = subBlockPossession.objects.filter(block=block)
            subs = []
            added = False
            for sub in subss:
                if sub.user == request.user.username:
                    added = True
                test = w3.eth.contract(address=sub.transaction_address, abi=abi1)
                print(test.functions.retrieve().call())

                results = test.functions.retrieve().call()
                s = {"status":results[0][0],"image":sub.pic,"username":sub.user,"date":sub.dateToday}
                subs.append(s)
            # print({"name":result[0][0].split(";")[0],"address":result[0][0].split(";")[1],"date":result[0][0].split(";")[2],"ipn":result[0][0].split(";")[3],"InsName":result[0][1].split(";")[0],"InsAdd":result[0][1].split(";")[1],"Npi":result[0][1].split(";")[2],"serviceDate":result[0][2].split(";")[0],"desc":result[0][2].split(";")[1],"pcode":result[0][2].split(";")[2],"dcode":result[0][2].split(";")[3],"charge":result[0][2].split(";")[4],"amount":result[0][3],"=====":result[0][4]})
            # return JsonResponse({"name":result[0][0].split(";")[0],"dob":result[0][0].split(";")[1],"address":result[0][0].split(";")[2],"father":result[0][0].split(";")[3],"mother":result[0][0].split(";")[4],"adhaar":result[0][0].split(";")[5],"qualification":result[0][1].split(";")[0],"institute":result[0][1].split(";")[1],"employer":result[0][2].split(";")[0],"designation":result[0][2].split(";")[1],"typeOrg":result[0][2].split(";")[2],"typeOcc":result[0][2].split(";")[3],"amount":result[0][3]})     +";"+request.POST.get('sslc_number')+";"+request.POST.get('ration_number')+";"+request.POST.get('gender')
            # personalInfo = request.POST.get('name')+";"+ request.POST.get('email')+";"+request.POST.get('phone') + ";" + request.POST.get("address")+ ";" + request.POST.get("city")+ ";" + request.POST.get("zip")
            # certficateInfo = request.POST.get('property_type')+";"+request.POST.get('property_address')+";"+request.POST.get('property_city')+";"+request.POST.get('property_zip')
   
            return render(request,'tracking.html',{"name":result[0][0].split(";")[0],"email":result[0][0].split(";")[1],"phone":result[0][0].split(";")[2],"address":result[0][0].split(";")[3],"city":result[0][0].split(";")[4],"zip":result[0][0].split(";")[5],"property_type":result[0][1].split(";")[0],"p_address":result[0][1].split(";")[1],"p_city":result[0][1].split(";")[2],"p_zip":result[0][1].split(";")[3],"profile":profile,"pk":block.pk,"blocks":subs,"added":added,"block":block,"certificate":2})
        
        else:
            request.session['found'] = 0
    


        return render(request,'index.html',context = {'profile':profile,"found":found})

    elif "NACID" in request.POST.get('query'):
        print("[+] ---------- Tracking  ---------- [+]" )
        with open("status.sol", "r") as file:
            contact_list_file = file.read()

        profile = userProfile.objects.filter(user = request.user).first()
        compiled_sol2 = compile_standard(
            {
                "language": "Solidity",
                "sources": {"status.sol": {"content": contact_list_file}},
                "settings": {
                    "outputSelection": {
                        "*": {
                            "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                        }
                    }
                },
            },
            solc_version="0.8.0",
        )
        # print(compiled_sol)
        with open("compiled_code1.json", "w") as file:
            json.dump(compiled_sol2, file)

        bytecode1 = compiled_sol2["contracts"]["status.sol"]["Status"]["evm"]["bytecode"]["object"]
        abi1 = json.loads(compiled_sol2["contracts"]["status.sol"]["Status"]["metadata"])["output"]["abi"]
        block = NativityCertificate.objects.filter(certificate_id = request.POST.get("query")).first()
            # request.POST.get('university_name') + str(request.POST.get('date_issued'))+ request.POST.get("c_no")+request.POST.get("reg_no")+request.POST.get("student_name")+request.POST.get("faculty_of")+ request.POST.get("degree_of")+request.POST.get("degree_in")+str(request.POST.get("completed_in"))+ request.POST.get("comp_1")+request.POST.get("comp_2")+request.POST.get("class")+request.POST.get("grade")+request.POST.get("course_name") + str(p_block.current_hash)
        bytecode = compiled_sol["contracts"]["ContactList.sol"]["NativityCertificate"]["evm"]["bytecode"]["object"]
        abi = json.loads(compiled_sol["contracts"]["ContactList.sol"]["NativityCertificate"]["metadata"])["output"]["abi"]
    
        if block:
            test = w3.eth.contract(address=block.transaction_address, abi=abi)
            print(test.functions.retrieve().call())

            result = test.functions.retrieve().call()
            print("result",result[0])
            request.session['found'] = 1
            profile = userProfile.objects.filter(user = request.user).first()
            
            subss = subBlockNativity.objects.filter(block=block)
            subs = []
            added = False
            for sub in subss:
                if sub.user == request.user.username:
                    added = True
                test = w3.eth.contract(address=sub.transaction_address, abi=abi1)
                print(test.functions.retrieve().call())

                results = test.functions.retrieve().call()
                s = {"status":results[0][0],"image":sub.pic,"username":sub.user,"date":sub.dateToday}
                subs.append(s)
            # print({"name":result[0][0].split(";")[0],"address":result[0][0].split(";")[1],"date":result[0][0].split(";")[2],"ipn":result[0][0].split(";")[3],"InsName":result[0][1].split(";")[0],"InsAdd":result[0][1].split(";")[1],"Npi":result[0][1].split(";")[2],"serviceDate":result[0][2].split(";")[0],"desc":result[0][2].split(";")[1],"pcode":result[0][2].split(";")[2],"dcode":result[0][2].split(";")[3],"charge":result[0][2].split(";")[4],"amount":result[0][3],"=====":result[0][4]})
            # return JsonResponse({"name":result[0][0].split(";")[0],"dob":result[0][0].split(";")[1],"address":result[0][0].split(";")[2],"father":result[0][0].split(";")[3],"mother":result[0][0].split(";")[4],"adhaar":result[0][0].split(";")[5],"qualification":result[0][1].split(";")[0],"institute":result[0][1].split(";")[1],"employer":result[0][2].split(";")[0],"designation":result[0][2].split(";")[1],"typeOrg":result[0][2].split(";")[2],"typeOcc":result[0][2].split(";")[3],"amount":result[0][3]})     +";"+request.POST.get('sslc_number')+";"+request.POST.get('ration_number')+";"+request.POST.get('gender')
            # personalInfo = request.POST.get('name')+";"+ request.POST.get('email')+";"+request.POST.get('phone') + ";" + request.POST.get("address")+ ";" + request.POST.get("city")+ ";" + request.POST.get("zip")
            # certficateInfo = request.POST.get('property_type')+";"+request.POST.get('property_address')+";"+request.POST.get('property_city')+";"+request.POST.get('property_zip')
            # personalInfo = request.POST.get('name')+";"+ request.POST.get('email')+";"+request.POST.get('phone') + ";" + request.POST.get("birth_place")+ ";" + str(request.POST.get("birth_date"))+ ";" + request.POST.get("father_name")+ ";" + request.POST.get("mother_name")+ ";" + request.POST.get("father_occupation")+ ";" + request.POST.get("mother_occupation")

            return render(request,'tracking.html',{"name":result[0][0].split(";")[0],"email":result[0][0].split(";")[1],"phone":result[0][0].split(";")[2],"bplace":result[0][0].split(";")[3],"date":result[0][0].split(";")[4],"f_name":result[0][0].split(";")[5],"m_name":result[0][0].split(";")[6],"f_o":result[0][0].split(";")[7],"m_o":result[0][0].split(";")[8],"profile":profile,"pk":block.pk,"blocks":subs,"added":added,"block":block,"certificate":3})
        
        else:
            request.session['found'] = 0
    


        return render(request,'index.html',context = {'profile':profile,"found":found})




def addStatus(request):
    with open("status.sol", "r") as file:
        contact_list_file = file.read()


    compiled_sol2 = compile_standard(
        {
            "language": "Solidity",
            "sources": {"status.sol": {"content": contact_list_file}},
            "settings": {
                "outputSelection": {
                    "*": {
                        "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                    }
                }
            },
        },
        solc_version="0.8.0",
    )
    # print(compiled_sol)
    with open("compiled_code1.json", "w") as file:
        json.dump(compiled_sol2, file)

    bytecode1 = compiled_sol2["contracts"]["status.sol"]["Status"]["evm"]["bytecode"]["object"]
    abi1 = json.loads(compiled_sol2["contracts"]["status.sol"]["Status"]["metadata"])["output"]["abi"]
    we3 = Web3(Web3.HTTPProvider("HTTP://127.0.0.1:7545"))
    chain_id = 1337
    address = "0x800A3BF5d9C6e42fFe4A57c7968618DdE81fd7cA"
    private_key = "e0a9f2f78b2dca326b4116744b422d2ba1ba5c15392492c3c45a2e3fbe9021b0" # leaving the private key like this is very insecure if you are working on real world project
    # leaving the private key like this is very insecure if you are working on real world project

    ContactList = we3.eth.contract(abi=abi1, bytecode=bytecode1)
# Get the number of latest transaction
    nonce = we3.eth.getTransactionCount(address)

    transaction = ContactList.constructor().buildTransaction(
        {
            "chainId": chain_id,
            "gasPrice": we3.eth.gas_price,
            "from": address,
            "nonce": nonce,
        }
    )
    # Sign the transaction
    sign_transaction = we3.eth.account.sign_transaction(transaction, private_key=private_key)
    print("Deploying Contract!")
    # Send the transaction
    transaction_hash = we3.eth.send_raw_transaction(sign_transaction.rawTransaction)
    # Wait for the transaction to be mined, and get the transaction receipt
    print("Waiting for transaction to finish...")
    transaction_receipt = we3.eth.wait_for_transaction_receipt(transaction_hash)
    print(f"Done! Contract deployed to {transaction_receipt.contractAddress}")
    profile = userProfile.objects.filter(user = request.user).first()
    block =IncomeCertificate.objects.filter(pk = request.POST.get('pk')).first()
    sub = subBlock.objects.create(transaction_address = str(transaction_receipt.contractAddress),pic = profile.image.url,user = request.user.username,block = block)
   
    # print("[+] Status :",status)
    contact_list = we3.eth.contract(address=transaction_receipt.contractAddress, abi=abi1)
    store_contact = contact_list.functions.addStatus(
        request.POST.get('status')
        
    ).buildTransaction({"chainId": chain_id, "from": address, "gasPrice": we3.eth.gas_price, "nonce": nonce + 1})

    # Sign the transaction
    sign_store_contact = we3.eth.account.sign_transaction(
        store_contact, private_key=private_key
    )
    # Send the transaction
    send_store_contact = we3.eth.send_raw_transaction(sign_store_contact.rawTransaction)
    transaction_receipt = we3.eth.wait_for_transaction_receipt(send_store_contact)

    print(contact_list.functions.retrieve().call())

    # used to get data from blockchain
    test = we3.eth.contract(address="0xb077f601fC034f11Eaa28D93985A4bD2Df80deEf", abi=abi)
    print(test.functions.retrieve().call())

    result = test.functions.retrieve().call()
    print("result",result[0][0])

    return HttpResponseRedirect(reverse('homepage'))

#---------------for caste cerificate status ----------------------

def addStatusCaste(request):
    with open("status.sol", "r") as file:
        contact_list_file = file.read()


    compiled_sol2 = compile_standard(
        {
            "language": "Solidity",
            "sources": {"status.sol": {"content": contact_list_file}},
            "settings": {
                "outputSelection": {
                    "*": {
                        "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                    }
                }
            },
        },
        solc_version="0.8.0",
    )
    # print(compiled_sol)
    with open("compiled_code1.json", "w") as file:
        json.dump(compiled_sol2, file)

    bytecode1 = compiled_sol2["contracts"]["status.sol"]["Status"]["evm"]["bytecode"]["object"]
    abi1 = json.loads(compiled_sol2["contracts"]["status.sol"]["Status"]["metadata"])["output"]["abi"]
    we3 = Web3(Web3.HTTPProvider("HTTP://127.0.0.1:7545"))
    chain_id = 1337
    address = "0x800A3BF5d9C6e42fFe4A57c7968618DdE81fd7cA"
    private_key = "e0a9f2f78b2dca326b4116744b422d2ba1ba5c15392492c3c45a2e3fbe9021b0" # leaving the private key like this is very insecure if you are working on real world project
    # leaving the private key like this is very insecure if you are working on real world project

    ContactList = we3.eth.contract(abi=abi1, bytecode=bytecode1)
# Get the number of latest transaction
    nonce = we3.eth.getTransactionCount(address)

    transaction = ContactList.constructor().buildTransaction(
        {
            "chainId": chain_id,
            "gasPrice": we3.eth.gas_price,
            "from": address,
            "nonce": nonce,
        }
    )
    # Sign the transaction
    sign_transaction = we3.eth.account.sign_transaction(transaction, private_key=private_key)
    print("Deploying Contract!")
    # Send the transaction
    transaction_hash = we3.eth.send_raw_transaction(sign_transaction.rawTransaction)
    # Wait for the transaction to be mined, and get the transaction receipt
    print("Waiting for transaction to finish...")
    transaction_receipt = we3.eth.wait_for_transaction_receipt(transaction_hash)
    print(f"Done! Contract deployed to {transaction_receipt.contractAddress}")
    profile = userProfile.objects.filter(user = request.user).first()
    block =CasteCertificate.objects.filter(pk = request.POST.get('pk')).first()
    sub = subBlockCaste.objects.create(transaction_address = str(transaction_receipt.contractAddress),pic = profile.image.url,user = request.user.username,block = block)
   
    # print("[+] Status :",status)
    contact_list = we3.eth.contract(address=transaction_receipt.contractAddress, abi=abi1)
    store_contact = contact_list.functions.addStatus(
        request.POST.get('status')
        
    ).buildTransaction({"chainId": chain_id, "from": address, "gasPrice": we3.eth.gas_price, "nonce": nonce + 1})

    # Sign the transaction
    sign_store_contact = we3.eth.account.sign_transaction(
        store_contact, private_key=private_key
    )
    # Send the transaction
    send_store_contact = we3.eth.send_raw_transaction(sign_store_contact.rawTransaction)
    transaction_receipt = we3.eth.wait_for_transaction_receipt(send_store_contact)

    print(contact_list.functions.retrieve().call())

    # used to get data from blockchain
    test = we3.eth.contract(address="0xb077f601fC034f11Eaa28D93985A4bD2Df80deEf", abi=abi)
    print(test.functions.retrieve().call())

    result = test.functions.retrieve().call()
    print("result",result[0][0])

    return HttpResponseRedirect(reverse('homepage'))


#-----------------------------------------------------------------



#---------------for possession cerificate status ----------------------

def addStatusPossession(request):
    with open("status.sol", "r") as file:
        contact_list_file = file.read()


    compiled_sol2 = compile_standard(
        {
            "language": "Solidity",
            "sources": {"status.sol": {"content": contact_list_file}},
            "settings": {
                "outputSelection": {
                    "*": {
                        "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                    }
                }
            },
        },
        solc_version="0.8.0",
    )
    # print(compiled_sol)
    with open("compiled_code1.json", "w") as file:
        json.dump(compiled_sol2, file)

    bytecode1 = compiled_sol2["contracts"]["status.sol"]["Status"]["evm"]["bytecode"]["object"]
    abi1 = json.loads(compiled_sol2["contracts"]["status.sol"]["Status"]["metadata"])["output"]["abi"]
    we3 = Web3(Web3.HTTPProvider("HTTP://127.0.0.1:7545"))
    chain_id = 1337
    address = "0x800A3BF5d9C6e42fFe4A57c7968618DdE81fd7cA"
    private_key = "e0a9f2f78b2dca326b4116744b422d2ba1ba5c15392492c3c45a2e3fbe9021b0" # leaving the private key like this is very insecure if you are working on real world project
    # leaving the private key like this is very insecure if you are working on real world project

    ContactList = we3.eth.contract(abi=abi1, bytecode=bytecode1)
# Get the number of latest transaction
    nonce = we3.eth.getTransactionCount(address)

    transaction = ContactList.constructor().buildTransaction(
        {
            "chainId": chain_id,
            "gasPrice": we3.eth.gas_price,
            "from": address,
            "nonce": nonce,
        }
    )
    # Sign the transaction
    sign_transaction = we3.eth.account.sign_transaction(transaction, private_key=private_key)
    print("Deploying Contract!")
    # Send the transaction
    transaction_hash = we3.eth.send_raw_transaction(sign_transaction.rawTransaction)
    # Wait for the transaction to be mined, and get the transaction receipt
    print("Waiting for transaction to finish...")
    transaction_receipt = we3.eth.wait_for_transaction_receipt(transaction_hash)
    print(f"Done! Contract deployed to {transaction_receipt.contractAddress}")
    profile = userProfile.objects.filter(user = request.user).first()
    block =PossessionCertificate.objects.filter(pk = request.POST.get('pk')).first()
    sub = subBlockPossession.objects.create(transaction_address = str(transaction_receipt.contractAddress),pic = profile.image.url,user = request.user.username,block = block)
   
    # print("[+] Status :",status)
    contact_list = we3.eth.contract(address=transaction_receipt.contractAddress, abi=abi1)
    store_contact = contact_list.functions.addStatus(
        request.POST.get('status')
        
    ).buildTransaction({"chainId": chain_id, "from": address, "gasPrice": we3.eth.gas_price, "nonce": nonce + 1})

    # Sign the transaction
    sign_store_contact = we3.eth.account.sign_transaction(
        store_contact, private_key=private_key
    )
    # Send the transaction
    send_store_contact = we3.eth.send_raw_transaction(sign_store_contact.rawTransaction)
    transaction_receipt = we3.eth.wait_for_transaction_receipt(send_store_contact)

    print(contact_list.functions.retrieve().call())

    # used to get data from blockchain
    # test = we3.eth.contract(address="0xb077f601fC034f11Eaa28D93985A4bD2Df80deEf", abi=abi)
    # print(test.functions.retrieve().call())

    # result = test.functions.retrieve().call()
    # print("result",result[0][0])

    return HttpResponseRedirect(reverse('homepage'))


#---------------for possession cerificate status ----------------------

def addStatusNativity(request):
    with open("status.sol", "r") as file:
        contact_list_file = file.read()


    compiled_sol2 = compile_standard(
        {
            "language": "Solidity",
            "sources": {"status.sol": {"content": contact_list_file}},
            "settings": {
                "outputSelection": {
                    "*": {
                        "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                    }
                }
            },
        },
        solc_version="0.8.0",
    )
    # print(compiled_sol)
    with open("compiled_code1.json", "w") as file:
        json.dump(compiled_sol2, file)

    bytecode1 = compiled_sol2["contracts"]["status.sol"]["Status"]["evm"]["bytecode"]["object"]
    abi1 = json.loads(compiled_sol2["contracts"]["status.sol"]["Status"]["metadata"])["output"]["abi"]
    we3 = Web3(Web3.HTTPProvider("HTTP://127.0.0.1:7545"))
    chain_id = 1337
    address = "0x800A3BF5d9C6e42fFe4A57c7968618DdE81fd7cA"
    private_key = "e0a9f2f78b2dca326b4116744b422d2ba1ba5c15392492c3c45a2e3fbe9021b0" # leaving the private key like this is very insecure if you are working on real world project
    # leaving the private key like this is very insecure if you are working on real world project

    ContactList = we3.eth.contract(abi=abi1, bytecode=bytecode1)
# Get the number of latest transaction
    nonce = we3.eth.getTransactionCount(address)

    transaction = ContactList.constructor().buildTransaction(
        {
            "chainId": chain_id,
            "gasPrice": we3.eth.gas_price,
            "from": address,
            "nonce": nonce,
        }
    )
    # Sign the transaction
    sign_transaction = we3.eth.account.sign_transaction(transaction, private_key=private_key)
    print("Deploying Contract!")
    # Send the transaction
    transaction_hash = we3.eth.send_raw_transaction(sign_transaction.rawTransaction)
    # Wait for the transaction to be mined, and get the transaction receipt
    print("Waiting for transaction to finish...")
    transaction_receipt = we3.eth.wait_for_transaction_receipt(transaction_hash)
    print(f"Done! Contract deployed to {transaction_receipt.contractAddress}")
    profile = userProfile.objects.filter(user = request.user).first()
    block =NativityCertificate.objects.filter(pk = request.POST.get('pk')).first()
    sub = subBlockNativity.objects.create(transaction_address = str(transaction_receipt.contractAddress),pic = profile.image.url,user = request.user.username,block = block)
   
    # print("[+] Status :",status)
    contact_list = we3.eth.contract(address=transaction_receipt.contractAddress, abi=abi1)
    store_contact = contact_list.functions.addStatus(
        request.POST.get('status')
        
    ).buildTransaction({"chainId": chain_id, "from": address, "gasPrice": we3.eth.gas_price, "nonce": nonce + 1})

    # Sign the transaction
    sign_store_contact = we3.eth.account.sign_transaction(
        store_contact, private_key=private_key
    )
    # Send the transaction
    send_store_contact = we3.eth.send_raw_transaction(sign_store_contact.rawTransaction)
    transaction_receipt = we3.eth.wait_for_transaction_receipt(send_store_contact)

    print(contact_list.functions.retrieve().call())

    # used to get data from blockchain
    # test = we3.eth.contract(address="0xb077f601fC034f11Eaa28D93985A4bD2Df80deEf", abi=abi)
    # print(test.functions.retrieve().call())

    # result = test.functions.retrieve().call()
    # print("result",result[0][0])

    return HttpResponseRedirect(reverse('homepage'))

def approve(request):
    with open("status.sol", "r") as file:
        contact_list_file = file.read()


    compiled_sol2 = compile_standard(
        {
            "language": "Solidity",
            "sources": {"status.sol": {"content": contact_list_file}},
            "settings": {
                "outputSelection": {
                    "*": {
                        "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                    }
                }
            },
        },
        solc_version="0.8.0",
    )
    # print(compiled_sol)
    with open("compiled_code1.json", "w") as file:
        json.dump(compiled_sol2, file)

    bytecode1 = compiled_sol2["contracts"]["status.sol"]["Status"]["evm"]["bytecode"]["object"]
    abi1 = json.loads(compiled_sol2["contracts"]["status.sol"]["Status"]["metadata"])["output"]["abi"]
    we3 = Web3(Web3.HTTPProvider("HTTP://127.0.0.1:7545"))
    chain_id = 1337
    address = "0x800A3BF5d9C6e42fFe4A57c7968618DdE81fd7cA"
    private_key = "e0a9f2f78b2dca326b4116744b422d2ba1ba5c15392492c3c45a2e3fbe9021b0" # leaving the private key like this is very insecure if you are working on real world project
    # leaving the private key like this is very insecure if you are working on real world project

    ContactList = we3.eth.contract(abi=abi1, bytecode=bytecode1)
# Get the number of latest transaction
    nonce = we3.eth.getTransactionCount(address)

    transaction = ContactList.constructor().buildTransaction(
        {
            "chainId": chain_id,
            "gasPrice": we3.eth.gas_price,
            "from": address,
            "nonce": nonce,
        }
    )
    # Sign the transaction
    sign_transaction = we3.eth.account.sign_transaction(transaction, private_key=private_key)
    print("Deploying Contract!")
    # Send the transaction
    transaction_hash = we3.eth.send_raw_transaction(sign_transaction.rawTransaction)
    # Wait for the transaction to be mined, and get the transaction receipt
    print("Waiting for transaction to finish...")
    transaction_receipt = we3.eth.wait_for_transaction_receipt(transaction_hash)
    print(f"Done! Contract deployed to {transaction_receipt.contractAddress}")
    profile = userProfile.objects.filter(user = request.user).first()
    
    block =IncomeCertificate.objects.filter(pk = request.POST.get('pk')).first()
    block.is_approved = True 
    block.save()

    sub = subBlock.objects.create(transaction_address = str(transaction_receipt.contractAddress),pic = profile.image.url,user = request.user.username,block = block)
    status = request.POST.get('status')

    
    status = request.POST.get('statusOfApplication')
    print("[+] Status :",status)
    contact_list = we3.eth.contract(address=transaction_receipt.contractAddress, abi=abi1)
    store_contact = contact_list.functions.addStatus(
        request.POST.get('statusOfApplication')
        
    ).buildTransaction({"chainId": chain_id, "from": address, "gasPrice": we3.eth.gas_price, "nonce": nonce + 1})

    # Sign the transaction
    sign_store_contact = we3.eth.account.sign_transaction(
        store_contact, private_key=private_key
    )
    # Send the transaction
    send_store_contact = we3.eth.send_raw_transaction(sign_store_contact.rawTransaction)
    transaction_receipt = we3.eth.wait_for_transaction_receipt(send_store_contact)

    print(contact_list.functions.retrieve().call())

    # used to get data from blockchain
    test = we3.eth.contract(address="0xb077f601fC034f11Eaa28D93985A4bD2Df80deEf", abi=abi)
    print(test.functions.retrieve().call())

    result = test.functions.retrieve().call()
    print("result",result[0][0])

    return HttpResponseRedirect(reverse('homepage'))


#For caste certificate ----------------------------------

def approveCasteCertificate(request):
    with open("status.sol", "r") as file:
        contact_list_file = file.read()


    compiled_sol2 = compile_standard(
        {
            "language": "Solidity",
            "sources": {"status.sol": {"content": contact_list_file}},
            "settings": {
                "outputSelection": {
                    "*": {
                        "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                    }
                }
            },
        },
        solc_version="0.8.0",
    )
    # print(compiled_sol)
    with open("compiled_code1.json", "w") as file:
        json.dump(compiled_sol2, file)

    bytecode1 = compiled_sol2["contracts"]["status.sol"]["Status"]["evm"]["bytecode"]["object"]
    abi1 = json.loads(compiled_sol2["contracts"]["status.sol"]["Status"]["metadata"])["output"]["abi"]
    we3 = Web3(Web3.HTTPProvider("HTTP://127.0.0.1:7545"))
    chain_id = 1337
    address = "0x800A3BF5d9C6e42fFe4A57c7968618DdE81fd7cA"
    private_key = "e0a9f2f78b2dca326b4116744b422d2ba1ba5c15392492c3c45a2e3fbe9021b0" # leaving the private key like this is very insecure if you are working on real world project
    # leaving the private key like this is very insecure if you are working on real world project

    ContactList = we3.eth.contract(abi=abi1, bytecode=bytecode1)
# Get the number of latest transaction
    nonce = we3.eth.getTransactionCount(address)

    transaction = ContactList.constructor().buildTransaction(
        {
            "chainId": chain_id,
            "gasPrice": we3.eth.gas_price,
            "from": address,
            "nonce": nonce,
        }
    )
    # Sign the transaction
    sign_transaction = we3.eth.account.sign_transaction(transaction, private_key=private_key)
    print("Deploying Contract!")
    # Send the transaction
    transaction_hash = we3.eth.send_raw_transaction(sign_transaction.rawTransaction)
    # Wait for the transaction to be mined, and get the transaction receipt
    print("Waiting for transaction to finish...")
    transaction_receipt = we3.eth.wait_for_transaction_receipt(transaction_hash)
    print(f"Done! Contract deployed to {transaction_receipt.contractAddress}")
    profile = userProfile.objects.filter(user = request.user).first()
    
    block =CasteCertificate.objects.filter(pk = request.POST.get('pk')).first()
    block.is_approved = True 
    block.save()

    sub = subBlockCaste.objects.create(transaction_address = str(transaction_receipt.contractAddress),pic = profile.image.url,user = request.user.username,block = block)
    status = request.POST.get('status')

    
    status = request.POST.get('statusOfApplication')
    print("[+] Status :",status)
    contact_list = we3.eth.contract(address=transaction_receipt.contractAddress, abi=abi1)
    store_contact = contact_list.functions.addStatus(
        request.POST.get('statusOfApplication')
        
    ).buildTransaction({"chainId": chain_id, "from": address, "gasPrice": we3.eth.gas_price, "nonce": nonce + 1})

    # Sign the transaction
    sign_store_contact = we3.eth.account.sign_transaction(
        store_contact, private_key=private_key
    )
    # Send the transaction
    send_store_contact = we3.eth.send_raw_transaction(sign_store_contact.rawTransaction)
    transaction_receipt = we3.eth.wait_for_transaction_receipt(send_store_contact)

    print(contact_list.functions.retrieve().call())

    # used to get data from blockchain
    # test = we3.eth.contract(address="0xb077f601fC034f11Eaa28D93985A4bD2Df80deEf", abi=abi)
    # print(test.functions.retrieve().call())

    # result = test.functions.retrieve().call()
    # print("result",result[0][0])

    return HttpResponseRedirect(reverse('homepage'))


#For possession certificate ----------------------------------

def approvePossessionCertificate(request):
    with open("status.sol", "r") as file:
        contact_list_file = file.read()


    compiled_sol2 = compile_standard(
        {
            "language": "Solidity",
            "sources": {"status.sol": {"content": contact_list_file}},
            "settings": {
                "outputSelection": {
                    "*": {
                        "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                    }
                }
            },
        },
        solc_version="0.8.0",
    )
    # print(compiled_sol)
    with open("compiled_code1.json", "w") as file:
        json.dump(compiled_sol2, file)

    bytecode1 = compiled_sol2["contracts"]["status.sol"]["Status"]["evm"]["bytecode"]["object"]
    abi1 = json.loads(compiled_sol2["contracts"]["status.sol"]["Status"]["metadata"])["output"]["abi"]
    we3 = Web3(Web3.HTTPProvider("HTTP://127.0.0.1:7545"))
    chain_id = 1337
    address = "0x800A3BF5d9C6e42fFe4A57c7968618DdE81fd7cA"
    private_key = "e0a9f2f78b2dca326b4116744b422d2ba1ba5c15392492c3c45a2e3fbe9021b0" # leaving the private key like this is very insecure if you are working on real world project
    # leaving the private key like this is very insecure if you are working on real world project

    ContactList = we3.eth.contract(abi=abi1, bytecode=bytecode1)
# Get the number of latest transaction
    nonce = we3.eth.getTransactionCount(address)

    transaction = ContactList.constructor().buildTransaction(
        {
            "chainId": chain_id,
            "gasPrice": we3.eth.gas_price,
            "from": address,
            "nonce": nonce,
        }
    )
    # Sign the transaction
    sign_transaction = we3.eth.account.sign_transaction(transaction, private_key=private_key)
    print("Deploying Contract!")
    # Send the transaction
    transaction_hash = we3.eth.send_raw_transaction(sign_transaction.rawTransaction)
    # Wait for the transaction to be mined, and get the transaction receipt
    print("Waiting for transaction to finish...")
    transaction_receipt = we3.eth.wait_for_transaction_receipt(transaction_hash)
    print(f"Done! Contract deployed to {transaction_receipt.contractAddress}")
    profile = userProfile.objects.filter(user = request.user).first()
    
    block =PossessionCertificate.objects.filter(pk = request.POST.get('pk')).first()
    block.is_approved = True 
    block.save()

    sub = subBlockPossession.objects.create(transaction_address = str(transaction_receipt.contractAddress),pic = profile.image.url,user = request.user.username,block = block)
    status = request.POST.get('status')

    
    status = request.POST.get('statusOfApplication')
    print("[+] Status :",status)
    contact_list = we3.eth.contract(address=transaction_receipt.contractAddress, abi=abi1)
    store_contact = contact_list.functions.addStatus(
        request.POST.get('statusOfApplication')
        
    ).buildTransaction({"chainId": chain_id, "from": address, "gasPrice": we3.eth.gas_price, "nonce": nonce + 1})

    # Sign the transaction
    sign_store_contact = we3.eth.account.sign_transaction(
        store_contact, private_key=private_key
    )
    # Send the transaction
    send_store_contact = we3.eth.send_raw_transaction(sign_store_contact.rawTransaction)
    transaction_receipt = we3.eth.wait_for_transaction_receipt(send_store_contact)

    print(contact_list.functions.retrieve().call())

    # used to get data from blockchain
    # test = we3.eth.contract(address="0xb077f601fC034f11Eaa28D93985A4bD2Df80deEf", abi=abi)
    # print(test.functions.retrieve().call())

    # result = test.functions.retrieve().call()
    # print("result",result[0][0])

    return HttpResponseRedirect(reverse('homepage'))

#For nativity certificate ----------------------------------

def approveNativityCertificate(request):
    with open("status.sol", "r") as file:
        contact_list_file = file.read()


    compiled_sol2 = compile_standard(
        {
            "language": "Solidity",
            "sources": {"status.sol": {"content": contact_list_file}},
            "settings": {
                "outputSelection": {
                    "*": {
                        "*": ["abi", "metadata", "evm.bytecode", "evm.bytecode.sourceMap"] # output needed to interact with and deploy contract 
                    }
                }
            },
        },
        solc_version="0.8.0",
    )
    # print(compiled_sol)
    with open("compiled_code1.json", "w") as file:
        json.dump(compiled_sol2, file)

    bytecode1 = compiled_sol2["contracts"]["status.sol"]["Status"]["evm"]["bytecode"]["object"]
    abi1 = json.loads(compiled_sol2["contracts"]["status.sol"]["Status"]["metadata"])["output"]["abi"]
    we3 = Web3(Web3.HTTPProvider("HTTP://127.0.0.1:7545"))
    chain_id = 1337
    address = "0x800A3BF5d9C6e42fFe4A57c7968618DdE81fd7cA"
    private_key = "e0a9f2f78b2dca326b4116744b422d2ba1ba5c15392492c3c45a2e3fbe9021b0" # leaving the private key like this is very insecure if you are working on real world project
    # leaving the private key like this is very insecure if you are working on real world project

    ContactList = we3.eth.contract(abi=abi1, bytecode=bytecode1)
# Get the number of latest transaction
    nonce = we3.eth.getTransactionCount(address)

    transaction = ContactList.constructor().buildTransaction(
        {
            "chainId": chain_id,
            "gasPrice": we3.eth.gas_price,
            "from": address,
            "nonce": nonce,
        }
    )
    # Sign the transaction
    sign_transaction = we3.eth.account.sign_transaction(transaction, private_key=private_key)
    print("Deploying Contract!")
    # Send the transaction
    transaction_hash = we3.eth.send_raw_transaction(sign_transaction.rawTransaction)
    # Wait for the transaction to be mined, and get the transaction receipt
    print("Waiting for transaction to finish...")
    transaction_receipt = we3.eth.wait_for_transaction_receipt(transaction_hash)
    print(f"Done! Contract deployed to {transaction_receipt.contractAddress}")
    profile = userProfile.objects.filter(user = request.user).first()
    
    block =NativityCertificate.objects.filter(pk = request.POST.get('pk')).first()
    block.is_approved = True 
    block.save()

    sub = subBlockNativity.objects.create(transaction_address = str(transaction_receipt.contractAddress),pic = profile.image.url,user = request.user.username,block = block)
    status = request.POST.get('status')

    
    status = request.POST.get('statusOfApplication')
    print("[+] Status :",status)
    contact_list = we3.eth.contract(address=transaction_receipt.contractAddress, abi=abi1)
    store_contact = contact_list.functions.addStatus(
        request.POST.get('statusOfApplication')
        
    ).buildTransaction({"chainId": chain_id, "from": address, "gasPrice": we3.eth.gas_price, "nonce": nonce + 1})

    # Sign the transaction
    sign_store_contact = we3.eth.account.sign_transaction(
        store_contact, private_key=private_key
    )
    # Send the transaction
    send_store_contact = we3.eth.send_raw_transaction(sign_store_contact.rawTransaction)
    transaction_receipt = we3.eth.wait_for_transaction_receipt(send_store_contact)

    print(contact_list.functions.retrieve().call())

    # used to get data from blockchain
    # test = we3.eth.contract(address="0xb077f601fC034f11Eaa28D93985A4bD2Df80deEf", abi=abi)
    # print(test.functions.retrieve().call())

    # result = test.functions.retrieve().call()
    # print("result",result[0][0])

    return HttpResponseRedirect(reverse('homepage'))


def close(request):
    request.session['added_certificate'] = 0
    return JsonResponse({"msg":1})



def blogs(request):

    blogs_all = Blog.objects.all()

    return render(request,'blogs.html',{"blogs":blogs_all})

def blogDetails(request):

    blog = Blog.objects.filter(pk = request.POST.get('pk')).first()

    return JsonResponse({"title":blog.title,"desc":blog.description,"image":blog.image.url})