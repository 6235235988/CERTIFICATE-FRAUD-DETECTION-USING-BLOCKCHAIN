from django.urls import path
from . import views 
# from django.conf.urls import url

urlpatterns = [
    
    path('',views.homepage,name = "homepage"),
    path('register/', views.register,name='register' ),
   
    path('login/', views.user_login, name='login'),
    path('checkLogin/', views.checkLogin, name = "checkLogin"),
    path('checkSignup/', views.checkSignup,name = 'checkSignup'),
    path('logout/', views.user_logout,name = 'logout'),
    path('addIncome/', views.addIncomeCertificate,name = 'addIncome'),
    path('addCaste/', views.addCasteCertificate,name = 'addCaste'),
    path('addPossession/', views.addPossession,name = 'addPossession'),
    path('addNativity/', views.addNativity,name = 'addNativity'),
    path('tracking/', views.tracking,name = 'tracking'),
    path('addStatus/', views.addStatus,name = 'addStatus'),
    path('addStatusCaste/', views.addStatusCaste,name = 'addStatusCaste'),
    path('addStatusPossession/', views.addStatusPossession,name = 'addStatusPossession'),
    path('addStatusNativity/', views.addStatusNativity,name = 'addStatusNativity'),
    path('approve/', views.approve,name = 'approve'),
    path('approveCasteCertificate/', views.approveCasteCertificate,name = 'approveCasteCertificate'),
    path('approvePossessionCertificate/', views.approvePossessionCertificate,name = 'approvePossessionCertificate'),
    path('approveNativityCertificate/', views.approveNativityCertificate,name = 'approveNativityCertificate'),
    path('close/', views.close,name = 'close'),
    path('blogs/', views.blogs,name = 'blogs'),
    path('blogDetails/', views.blogDetails,name = 'blogDetails'),
]