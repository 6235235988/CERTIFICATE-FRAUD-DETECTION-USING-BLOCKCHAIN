from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class userProfile(models.Model):

    user = models.ForeignKey(User,on_delete=models.CASCADE)
    
    image = models.ImageField(upload_to='profile_pic',default='sherlock.jpg')
    phone = models.CharField(max_length=500)
    address = models.CharField(max_length=5000)
    is_employee = models.BooleanField(default=False)
    adhaar_no = models.CharField(max_length=5000)
    
    def __str__(self):
        return self.user.username + " profile"


class IncomeCertificate(models.Model):
    username = models.CharField(max_length=1000,blank=True)
    transaction_address = models.CharField(max_length=50000)
    certificate_id = models.CharField(max_length=1500)
    status = models.CharField(max_length=50000)
    is_approved = models.BooleanField(default=False)
    def __str__(self):
        return "Block"


class CasteCertificate(models.Model):
    username = models.CharField(max_length=1000,blank=True)
    transaction_address = models.CharField(max_length=50000)
    certificate_id = models.CharField(max_length=1500)
    status = models.CharField(max_length=50000)
    is_approved = models.BooleanField(default=False)
    def __str__(self):
        return "Block"


class Count(models.Model):
    number = models.IntegerField(default=0)
    def __str__(self):
        return "Number"


class subBlock(models.Model):

    user = models.CharField(max_length=50000)
    block = models.ForeignKey(IncomeCertificate,on_delete=models.CASCADE)
    pic = models.CharField(max_length=5000,default="")
    transaction_address = models.CharField(max_length=50000)
    dateToday = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return "sub block"
    

class subBlockCaste(models.Model):

    user = models.CharField(max_length=50000)
    block = models.ForeignKey(CasteCertificate,on_delete=models.CASCADE)
    pic = models.CharField(max_length=5000,default="")
    transaction_address = models.CharField(max_length=50000)
    dateToday = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return "sub block"
    

class Blog(models.Model):

    # user = models.CharField(max_length=50000)
    title = models.CharField(max_length=5000,default="")
    image = models.ImageField(upload_to='blog',default='sherlock.jpg')
    description = models.CharField(max_length=50000)
    
    def __str__(self):
        return self.title + " blog"
    

class PossessionCertificate(models.Model):
    username = models.CharField(max_length=1000,blank=True)
    transaction_address = models.CharField(max_length=50000)
    certificate_id = models.CharField(max_length=1500)
    status = models.CharField(max_length=50000)
    is_approved = models.BooleanField(default=False)
    def __str__(self):
        return "Block"
    
class subBlockPossession(models.Model):

    user = models.CharField(max_length=50000)
    block = models.ForeignKey(PossessionCertificate,on_delete=models.CASCADE)
    pic = models.CharField(max_length=5000,default="")
    transaction_address = models.CharField(max_length=50000)
    dateToday = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return "sub block"
    

class NativityCertificate(models.Model):
    username = models.CharField(max_length=1000,blank=True)
    transaction_address = models.CharField(max_length=50000)
    certificate_id = models.CharField(max_length=1500)
    status = models.CharField(max_length=50000)
    is_approved = models.BooleanField(default=False)
    def __str__(self):
        return "Block"
    
class subBlockNativity(models.Model):

    user = models.CharField(max_length=50000)
    block = models.ForeignKey(NativityCertificate,on_delete=models.CASCADE)
    pic = models.CharField(max_length=5000,default="")
    transaction_address = models.CharField(max_length=50000)
    dateToday = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return "sub block"